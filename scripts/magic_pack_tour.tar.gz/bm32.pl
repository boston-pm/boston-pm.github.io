#!/usr/local/bin/perl
# from
# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/1062.html

use strict;
use warnings;
use Benchmark qw( :all);

# use Text::Table;
my $DEBUG = $ENV{DEBUG};

my %Funcs = (
    direct     => 'direct( int rand 2**32)',
    decr       => 'decr( int rand 2**32)',
    ilya       => 'ilya( int rand 2**32)',
    table      => 'table( int rand 2**32)',
    unroll     => 'unroll( int rand 2**32)',
    unrmsk     => 'unrmsk( int rand 2**32)',
    tabunr     => 'tabunr( int rand 2**32)',
    katz       => 'katz( int rand 2**32)',
    packtut    => 'packtut( int rand 2**32)',
    ls1b       => 'ls1b( int rand 2**32)',
    parmod     => 'parmod( int rand 2**32)',
    rec_n      => 'rec_n( int rand 2**32)',
    sprtr      => 'sprtr( int rand 2**32)',
    hakmem_169 => 'hakmem_169( int rand 2**32)',
    ones32     => 'ones32( int rand 2**32)',

    # hakmem3 => 'hakmem3( int rand 2**32)', ## 64
    # hakmem4 => 'hakmem4( int rand 2**32)', ## 64
    #    via_bitvec => 'via_bitvec( int rand 2**32)',
);

my @Funcs =
  sort keys %Funcs;

#	qw/ilya unroll unrmsk/
#	qw/direct hakmem3 hakmem4/
#	qw/direct packtut katz /
#	qw/direct ilya unroll /
#	qw/parmod /
#	qw/tabunr /
#

if ( $ENV{bench} ) {
    cmpthese( -10, { ( map { ( $_ => $Funcs{$_} ) } @Funcs ) } );
    exit;
}

use Test::More qw/no_plan/;
my %Tests = (
    1 => 1,
    7 => 3,
    ( ( 1 << 28 ) + ( 1 << 4 ) ) => 2,
    ( ( 1 << 44 ) + ( 1 << 28 ) + ( 1 << 4 ) ) => 3,

    # from  http://wiki.cs.pdx.edu/gitweb?p=popcount.git;a=tree
    0x00000080, 1,
    0x000000f0, 4,
    0x00008000, 1,
    0x0000f000, 4,
    0x00800000, 1,
    0x00f00000, 4,
    0x80000000, 1,
    0xf0000000, 4,
    0xff000000, 8,
    0x000000ff, 8,
    0x01fe0000, 8,
    0xea9031e8, 14,
    0x2e8eb2b2, 16,
    0x9b8be5b7, 20,
    ~0,         32,    # if 32 bit

    #   ~0, 64, # if 64 bit
    0, 0,

    #
    0xf000000f => 8,

);

while ( my ( $i, $ci ) = each %Tests ) {

    # is(direct($i),$ci,qq{Test-direct-$i-$ci})
    for my $f (@Funcs) {
        no strict "refs";
        is( &$f($i), $ci, qq{Test-$f-$i-$ci} . sprintf( qq{=x%x}, $i ) );
    }
}

if (1) {
    for my $n ( 1 .. 100 ) {
        my $cn = direct($n);       ## assumed to work
        my $i  = int rand 2**32;
        my $ci = direct($i);       ## assumed to work
        for my $f (@Funcs) {
            no strict "refs";
            is( &$f($n), $cn, qq{$f-n-$n} . sprintf( qq{=x%x},  $n ) );
            is( &$f($i), $ci, qq{$f-ri-$i} . sprintf( qq{=x%x}, $i ) );
            is( &$f( 1 << $n ),
                1, qq{$f-2**n-$n} . sprintf( qq{=x%x}, 1 << $n ) )
              if $n < 64;

        }
    }
}

###################################################################

# bit counting
# see also
# http://infolab.stanford.edu/~manku/bitcount/bitcount.html
# http://www.setbb.com/phpbb/viewtopic.php?mforum=sudoku&p=7629
# http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/

sub hakmem_169 {

# octal 11111111111 = decimal 1227133513 =  hex 0x49249249 = (as time_t) Wed Nov 19 22:25:13 UTC 2008
# This number is sacred to HAKMEM 169, bitcount.
# http://blogs.msdn.com/jeuge/archive/2005/06/08/HAKMEM-Bit-Count.aspx
# http://www.inwap.com/pdp10/hbaker/hakmem/hakmem.html
# http://www.inwap.com/pdp10/hbaker/hakmem/hacks.html#item169
# For 64-bit numbers, we would have to add triples of octal digits and use modulus 1023
### WRONG, it's 511 !
## does that make it loglog N ?
    #		printf("\n") if $DEBUG;
    my $u = shift;
    my $uCount =
      $u - ( ( $u >> 1 ) & 033333333333 ) - ( ( $u >> 2 ) & 011111111111 );
    return ( ( $uCount + ( $uCount >> 3 ) ) & 030707070707 ) % 63;

    # note that can not replace % with & trivially ... % is not always cheap

}

sub rec_n {

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0642.html
# Recursive approach, terse and elegant IMHO.
# An iterative one is OK as well.
    my $n = shift;
    return 0 unless $n;
    return ( $n & 1 ) + rec_n( $n >> 1 );
}

sub sprtr {

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0785.html
    qq.@{[map sprintf('%b',$_),@_]}. =~ tr/1//;
}

sub direct {
    my $x     = shift;
    my $count = 0;
    while ($x) {
        $count += $x & 1;
        $x >>= 1;
    }
    $count;
}

sub decr {
    my $x     = shift;
    my $count = 0;
    while ($x) {
        $count++;
        $x &= $x - 1;
    }
    $count;
}

sub ilya {

    # claims log N time
    # classic parallel bit counting
    my $x     = shift;
    my $shift = 1;
    for my $mask ( 0x55555555, 0x33333333, 0x0f0f0f0f, 0x00ff00ff, 0x0000ffff )
    {
        $x = ( $x & $mask ) + ( ( $x >> $shift ) & $mask );
        $shift *= 2;
    }
    $x;
}

sub unroll    # ilya unrolled
{

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/1067.html
# aka #4 on http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/
    my $n = shift;

    # can use same mask twice if shift $n then mask
    # n = (n & MASK_01010101) + ((n >> 1) & MASK_01010101) ;
    $n = ( $n & 0x55555555 ) + ( ( $n & 0xaaaaaaaa ) >> 1 );
    $n = ( $n & 0x33333333 ) + ( ( $n & 0xcccccccc ) >> 2 );
    $n = ( $n & 0x0f0f0f0f ) + ( ( $n & 0xf0f0f0f0 ) >> 4 );
    $n = ( $n & 0x00ff00ff ) + ( ( $n & 0xff00ff00 ) >> 8 );
    $n = ( $n & 0x0000ffff ) + ( ( $n & 0xffff0000 ) >> 16 );
### Last couple can be combined as
## += >> without the masks and a final mask taken since only 7 bits of 64 are needed

    $n;
}

sub unrmsk {

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/1067.html
# aka #4 on http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/
# (for 64bit) as modified per the 32bit at
# http://aggregate.ee.engr.uky.edu/MAGIC/#Population%20Count%20(Ones%20Count)
    my $n = shift;

    # can use same mask twice if shift $n then mask
    # n = (n & MASK_01010101) + ((n >> 1) & MASK_01010101) ;
    $n = ( $n & 0x55555555 ) + ( ( $n & 0xaaaaaaaa ) >> 1 );    # 1+1=2 in 2
    $n = ( $n & 0x33333333 ) + ( ( $n & 0xcccccccc ) >> 2 );    # max 4:3 of 4
    $n = ( $n & 0x0f0f0f0f ) + ( ( $n & 0xf0f0f0f0 ) >> 4 );    # max 8:4 of 8
    ### f's could be 7's since max value 4, but could carry to 0x8
    $n += ( $n >> 8 );     # max 16:5of16 -- no mask needed
    $n += ( $n >> 16 );    # max 32:6:of32
    ## $n +=  ($n  >> 32);# max 64:7of64 ## 64
    # this optimization saves ~ 8% off the literal unrolling
    ## += >> without the masks and a final mask taken
    ## since only 7 bits of 64 are needed
    ## note that this could be accumulated to result of a many-word scan here
    ## just have to mask to the point of maxresult.

    $n & 0x7f;
}

sub parmod                 # ilya unrolled plus modulus
{

# #5 on http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/
    my $n = shift;

    # can use same mask twice if shift $n then mask
    # n = (n & MASK_01010101) + ((n >> 1) & MASK_01010101) ;
    $n = ( $n & 0x55555555 ) + ( ( $n & 0xaaaaaaaa ) >> 1 );
    $n = ( $n & 0x33333333 ) + ( ( $n & 0xcccccccc ) >> 2 );
    $n = ( $n & 0x0f0f0f0f ) + ( ( $n & 0xf0f0f0f0 ) >> 4 );

    #       # $n = ($n & 0x00ff00ff) + (($n & 0xff00ff00) >> 8);
    #       # $n = ($n & 0x0000ffff) + (($n & 0xffff0000) >> 16);
    return $n % 255;
    ### casting-out-9's trick to sum digits base 256
}

# Population Count (Ones Count)

# http://aggregate.ee.engr.uky.edu/MAGIC/#Next%20Largest%20Power%20of%202
# The population count of a binary integer value x is the number
# of one bits in the value. Although many machines have single
# instructions for this, the single instructions are usually
# microcoded loops that test a bit per cycle; a log-time
# algorithm coded in C is often faster. The following code uses a
# variable-precision SWAR algorithm to perform a tree reduction
# adding the bits in a 32-bit value:
#
sub ones32    #(register unsigned int x)
{

    # 32-bit recursive reduction using SWAR...
    #   but first step is mapping 2-bit values
    #   into sum of 2 1-bit values in sneaky way

    my $x = shift;
    $x -= ( ( $x >> 1 ) & 0x55555555 );
    $x = ( ( ( $x >> 2 ) & 0x33333333 ) + ( $x & 0x33333333 ) );
    $x = ( ( ( $x >> 4 ) + $x ) & 0x0f0f0f0f );
    $x += ( $x >> 8 );
    $x += ( $x >> 16 );
    return ( $x & 0x0000003f );
}

sub katz {

    # from ftp.port80.se/pub/CPAN/authors/id/Y/YA/YARBER/kat.pl-1.03
    my $list = unpack( 'B*', pack( 'I*', shift ) );    ## 32
           # my $list = unpack('B*', pack('Q*',shift) ); ## 64
    $list =~ tr/0//d;

    # my $len = length($data);
    my $total = length($list);

    #my $avg = $len * 4;
    #my $dif = $total - $avg;
    #print("$len bytes, $total 1-bits ($avg + $dif)\n\n");
    return $total;
}

sub packtut {

# http://perldoc.perl.org/perlpacktut.html#Doing-Sums
# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0656.html
    my $bitcount = unpack( '%32b*', pack( 'I*', shift ) );    ## 32

    #   my $bitcount = unpack( '%64b*', pack('Q*',shift ));  ## 64
    #                            ^^           ^

}

sub ls1b {

# size2 http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0656.html
# Wegner-Kernighan
    my $n = shift;
    my $size = $n ? 1 : 0;
    $size++ while $n ^= ( ( $n - 1 ) ^ $n ) & $n;
    $size;
}

###############
# trade space for time ...
# and still is proprotional to wordsize N linear
#
my @table;

BEGIN {
    $table[$_] = direct($_)
      for 0 .. 255;    # not the most efficient pre-computation either ...
}

sub table {
    my $x     = shift;
    my $count = 0;
    while ($x) {
        $count += $table[ $x & 255 ];
        $x >>= 8;
    }
    $count;
}

sub tabunr {

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/1685.html
    my $x = shift;
    $table[ $x & 0xff ] +
      $table[ ( $x >> 8 ) & 0xff ] +
      $table[ ( $x >> 16 ) & 0xff ] +
      $table[ ( $x >> 24 ) & 0xff ]

     #       + $table [ ($x >> 32) & 0xff ] + $table [ ($x >> 40) & 0xff ] ## 64
     #       + $table [ ($x >> 48) & 0xff ] + $table [ ($x >> 56) & 0xff ] ## 64
      ;
}

################################
## module bitvec
__END__
  use Bit::Vector;

  my $vec = Bit::Vector->new(Bit::Vector->Word_Bits());



  sub via_bitvec {
      $vec->Word_Store(0,$_[0]);
      $vec->Norm();
  }



