#! /usr/bin/env perl -l
### Copyright - 2005 William Ricker / N1VUX
### License - Same as Perl
### Purpose - Find Words that are time_t's or vice versa

use warnings;
use strict;
use English qw{-no-match-vars};

## ARGS
our $Char = q{B};    ##Default because BILL'o'Clock is what I want
my $arg = shift @ARGV;
$Char = $arg if defined $arg and $arg =~ m{ \A \w{1} \Z }xsmi;
our $IsUC = $Char =~ /[A-Z]/ ? 1 : 0;

our %Time_of;

sub bytes_to_nums {
    my $string = shift;
    ## Probably has problems if given more than 4 chars?
    my $long = unpack( "N*", pack( "a*", $string ) );
    return $long;
}

sub keep_it {
    my $time_in = shift
      or die "keep_it requires arg";

    our %Time_of;

    my ( $Baaa, $BAAA ) = ( $time_in, ( $IsUC ? uc $time_in : lc $time_in ) );
    $Baaa =~ s/^$Char/$Char/i;    ## Force capital

    my $timet = bytes_to_nums($Baaa);
    $Time_of{$Baaa} = $timet;

    if ( $Baaa ne $BAAA ) {
        $timet = bytes_to_nums($BAAA);
        $Time_of{$BAAA} = $timet;
    }
}

## Friends ##
keep_it("Boyd") if $Char eq q{B};
keep_it("Byrd") if $Char eq q{B};    # is in Larry,Jim,Henry

### @TBD -- we could optionally use other dictionaries
open my $DICT, '<', '/usr/dict/words'
  or die "Dict open fails $OS_ERROR";

while (<$DICT>) {
    chomp;
    next unless m{ \A $Char \w{3} \Z }xism;    ## B... only
    keep_it($_);
}

for my $word ( sort keys %Time_of ) {
    my $timet = $Time_of{$word};
    my ( $gmt, $localt ) = ( scalar gmtime $timet, scalar localtime $timet );
    print qq{$word  $gmt GMT . $localt ET};
}
