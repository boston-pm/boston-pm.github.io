#! /usr/bin/perl

# http://www.google.com/search?q=2038+date

use POSIX;
$ENV{'TZ'} = "GMT";

my $eow = 2147483641;
for ( $clock = $eow ; $clock < 2147483651 ; $clock++ ) {
    my $dt = $clock - $eow - 7;
    print "@{[$dt > 0 ? '+':'']}$dt @{[ctime($clock)]}";
}

