#! /export/home/a273121/perl-5.10.0-RC2/perl  -l
# http://use.perl.org/comments.pl?sid=40855&cid=64834

require 5.010;
use Benchmark qw( :all);

our $quiet = 0;

for (@ARGV) {
    test_it(*log2_xx) if /xx/i;
    test_it(*log2_2)  if /2/i;
    test_it(*log2_3)  if /3/i;
    test_it(*log2_1)  if /1/i;
    test_it(*log2_Lc) if /const/i;

    test_it(*floor_log2)    if /swar/i;
    test_it(*floor_log2_pt) if /pt/i;

    print log(2) if /CC/i;

    # cmpthese can be used both ways as well
    $quiet = 1 and cmpthese(
        $count,
        {
            map { ( $_ => "test_it(\*$_) for 1..10" ) }
              qw/log2_LL  log2_xx log2_2 log2_1 log2_3 log2_0  floor_log2 floor_log2_pt/
        }
    ) if /bench/i;
    $quiet = 1 and cmpthese(
        $count,
        {
            map { ( $_ => "test_it(\*$_) for 1..10" ) }
              qw/log2_LL log2_Lc log2_Lcs /
        }
    ) if /LL/i;

}

sub log2_0 {
    my $n = shift;

    # print "n=$n";
    die "log2 is only defined on positive numbers, n $n not" if $n <= 0;
    my $str = unpack( "B12", pack( "F>", $n ) );
    $str =~ s/^[01]/00000/;    # drop sign and pad
    my $exp = unpack( "s>", pack( "B*", $str ) );
    return -1023 + $exp;
}

sub log2_1 {
    my $n = shift;

    # print "n=$n";
    die "log2 is only defined on positive numbers" if $n <= 0;
    my $str = unpack( "B28", pack( "F>", $n ) );
    $str =~ s/^[01]/00000/;    # drop sign and pad
    my ( $exp, $mant ) = unpack( "S>*", pack( "B*", $str ) );

    # print "exp= $exp mant=$mant";
    # printf "mant=%x \n",$mant;

    return -1023               # offset
      + $exp + (
        $mant >= 0xffff
        ? 1.00                 # synonym !
        : $mant >= 0x6a09 ? 0.50
        : 0
      );
}

sub log2_2 {
    my $n = shift;

    # print "n=$n";
    die "log2 is only defined on positive numbers" if $n <= 0;
    my $str = unpack( "B28", pack( "F>", $n ) );
    $str =~ s/^[01]/00000/;    # drop sign and pad
    my ( $exp, $mant ) = unpack( "S>*", pack( "B*", $str ) );

    # print "exp= $exp mant=$mant";
    printf "[EXP=%d 2^%d * 1x%04x]", $exp, $exp - 1023, $mant
      unless $quiet;

    return -1023               # offset
      + $exp + (
        $mant >= 0xffff
        ? 1.00                 # synonym !
        : $mant >= 0xae89 ? 0.75
        : $mant >= 0x6a09 ? 0.50
        : $mant >= 0x306f ? 0.25
        : 0
      );
}

sub log2_3 {
    my $n = shift;

    # print "n=$n";
    die "log2 is only defined on positive numbers" if $n <= 0;
    my $str = unpack( "B28", pack( "F>", $n ) );
    $str =~ s/^[01]/00000/;    # drop sign and pad
    my ( $exp, $mant ) = unpack( "S>*", pack( "B*", $str ) );

    #  print "exp= $exp mant=$mant";
    printf "[EXP=%d 2^%d * 1x%04x]", $exp, $exp - 1023, $mant
      unless $quiet;

    my $ee = -1023             # offset
      + $exp;

    return $ee + (
        $mant >= 0xffff
        ? 1.000                # synonym !
        : $mant >= 0xd581 ? 0.875
        : $mant >= 0xae89 ? 0.750
        : $mant >= 0x8ace ? 0.625
        : $mant >= 0x6a09 ? 0.500
        : $mant >= 0x4bfd ? 0.375
        : $mant >= 0x306f ? 0.250
        : $mant >= 0x172b ? 0.125
        : 0.000
    ) if $ee >= 0;

    # fractions ...
    return $ee + (
        $mant >= 0xffff
        ? 1.000    # synonym !
        : $mant <= 0x0fff ? 0.000
        : $mant <= 0x172b ? 0.125
        : $mant <= 0x306f ? 0.250
        : $mant <= 0x4bfd ? 0.375
        : $mant <= 0x6a09 ? 0.500
        : $mant <= 0x8ace ? 0.625
        : $mant <= 0xae89 ? 0.750
        : $mant <= 0xd581 ? 0.875
        : 0.999
      )

      # 3rd frac bit but that doubles tests again ...
      # this gives trunc @ 2bits not rounding,
      # but that allows caller to
      # round or trunc to ints.
}

our @Table;

INIT {
    @Table = map {
        log2_LL(
            unpack(
                "F>",
                pack( "H16",
                    '3ff' . unpack( 'H2', pack( 's', $_ ) ) . ( '0' x 13 ) )
            )
          )
    } 0 .. 255;
}

sub log2_xx {
    my $n = shift;

    # print "n=$n";
    die "log2 is only defined on positive numbers" if $n <= 0;
    my $str = unpack( "B28", pack( "F>", $n ) );
    $str =~ s/^[01]/00000/;    # drop sign and pad
    my ( $exp, $mant ) = unpack( "S>*", pack( "B*", $str ) );

    #  print "exp= $exp mant=$mant";
    printf "[EXP=%d 2^%d * 1x%04x]", $exp, $exp - 1023, $mant
      unless $quiet;

    my $ee = -1023             # offset
      + $exp;
    my $frac = $Table[ $mant >> 8 ];
    printf "[%2x: %g]", $mant >> 8, $frac
      unless $quiet;

    return $ee + $frac;

}

# from http://aggregate.ee.engr.uky.edu/MAGIC/#Log2%20of%20an%20Integer C code
sub floor_log2                 #(register unsigned int x)
{
    my $x = shift;
    $x |= ( $x >> 1 );
    $x |= ( $x >> 2 );
    $x |= ( $x >> 4 );
    $x |= ( $x >> 8 );
    $x |= ( $x >> 16 );

    #ifdef	LOG0UNDEFINED
    return ( ones32($x) - 1 );

    #else
    #	return(ones32($x >> 1));
    #endif
}

# Population Count (Ones Count)

# http://aggregate.ee.engr.uky.edu/MAGIC/#Next%20Largest%20Power%20of%202
# The population count of a binary integer value x is the number
# of one bits in the value. Although many machines have single
# instructions for this, the single instructions are usually
# microcoded loops that test a bit per cycle; a log-time
# algorithm coded in C is often faster. The following code uses a
# variable-precision SWAR algorithm to perform a tree reduction
# adding the bits in a 32-bit value:
#

# unsigned int
sub ones32    #(register unsigned int x)
{

    # 32-bit recursive reduction using SWAR...
    #   but first step is mapping 2-bit values
    #   into sum of 2 1-bit values in sneaky way

    my $x = shift;
    $x -= ( ( $x >> 1 ) & 0x55555555 );
    $x = ( ( ( $x >> 2 ) & 0x33333333 ) + ( $x & 0x33333333 ) );
    $x = ( ( ( $x >> 4 ) + $x ) & 0x0f0f0f0f );
    $x += ( $x >> 8 );
    $x += ( $x >> 16 );
    return ( $x & 0x0000003f );
}

sub floor_log2_pt    #(register unsigned int x)
{
    my $x = shift;
    $x |= ( $x >> 1 );
    $x |= ( $x >> 2 );
    $x |= ( $x >> 4 );
    $x |= ( $x >> 8 );
    $x |= ( $x >> 16 );

    #ifdef	LOG0UNDEFINED
    return ( unpack( '%32b*', pack( 'I*', $x ) ) - 1 );

    #else
    #	return(ones32($x >> 1));
    #endif
}

# --------------------------------------------------------------

# TEST

sub log2_LL {    # gold standard

    #  my $n = shift; -- wastes 4% !!
    return log(shift) / log(2);
}

require 5.010;    # 5.9.4
use feature 'state';

sub log2_Lcs {
    state $Le_2= log(2);

    #  my $n = shift;
    return log(shift) / $Le_2;
}

{                 #block
    my $Le_2;
    INIT { $Le_2 = log(2); }

    sub log2_Lc {

        #  my $n = shift;
        return log(shift) / $Le_2;
    }
}    #block

#=======================================

{    # block

    my $log2;    # func pointer

    sub compare_it {
        my ($n) = @_;
        printf "log2(%g)", $n
          unless $quiet;
        my ( $n1, $n2 ) = ( $log2->($n), log2_LL($n) );
        my $d  = $n2 - $n1;
        my $dp = 100 * $d / $n2;
        printf "= %g ~ %g (%g; %d\%)\n", $n1, $n2, $d, $dp
          unless $quiet;
    }

    sub test_it {

        $log2 = shift;

        print "\n\n$log2 : \n"
          unless $quiet;
        compare_it(3.1415926);
        compare_it($_) for 2 .. 7;
        compare_it( sqrt 2 );
        compare_it( sqrt sqrt 2 );
        compare_it( ( sqrt sqrt 2 )**3 );

        $quiet
          or printf "2^($_/2) " and compare_it( ( sqrt 2 )**$_ )
          for 1 .. 4;
        $quiet
          or printf "2^($_/4) " and compare_it( ( sqrt sqrt 2 )**$_ )
          for 1 .. 4;
        $quiet
          or printf "2^($_/8) " and compare_it( ( sqrt sqrt sqrt 2 )**$_ )
          for 1 .. 8;
        $quiet
          or printf "2^-($_/8) " and compare_it( ( sqrt sqrt sqrt 2 )**-$_ )
          for 1 .. 8;
        $quiet or print "\n";

        compare_it( 1.0 / $_ ) for 2 .. 12;
        compare_it(0.999);

        compare_it( 2**-10 );
        compare_it( 2**+10 );

        if ( !$quiet ) {
            print "\n bads...";
            eval { print $log2->(-1) } or print $!, $@;
            eval { print $log2->(0) }  or print $!, $@;
        }
    }    # end test
}    # END BLOCK

