#! perl -l
require 5.010;
use strict;
use warnings;

# my $nn = 0.75;
#print unpack("H*",pack("F>",$nn)),"\n";

my @XX;

=for skip
for 	 my $xx (0 .. 255 )
{
	my $x=pack("H16",'3ff'.unpack('H2',pack('s',$xx)).('0'x13));

	my $Fx = unpack("H*",$x),"\n";

	my $Fn = unpack("F>",$x);

	my $L2n=log2($Fn);

	printf	 "log2(%3d/256 = %8g = %s) = %g \n", $xx,$Fn,$Fx,$L2n;
			 ;

	push @XX, $L2n;
}
=cut

@XX = map {
    log2(
        unpack(
            "F>",
            pack( "H16",
                '3ff' . unpack( 'H2', pack( 's', $_ ) ) . ( '0' x 13 ) )
        )
      )
} 0 .. 255;

use Data::Dumper;
print Dumper( \@XX ), "\n";

our $_l2;
INIT { our $_l2 = log(2); }

sub log2 {
    return log(shift) / log(2);
}
