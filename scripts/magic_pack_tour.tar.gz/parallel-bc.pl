#! perl

=h1 (4) Parallel Count


http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/

#define TWO(c)     (0x1u << (c))
#define MASK(c)    (((unsigned int)(-1)) / (TWO(TWO(c)) + 1u))
#define COUNT(x,c) ((x) & MASK(c)) + (((x) >> (TWO(c))) & MASK(c))

int bitcount (unsigned int n)  {
   n = COUNT(n, 0) ;
   n = COUNT(n, 1) ;
   n = COUNT(n, 2) ;
   n = COUNT(n, 3) ;
   n = COUNT(n, 4) ;
   /* n = COUNT(n, 5) ;    for 64-bit integers */
   return n ;
}

Parallel Count carries out bit counting in a parallel fashion. Consider n after the first line has finished executing. Imagine splitting n into pairs of bits. Each pair contains the number of ones in those two bit positions in the original n. After the second line has finished executing, each nibble contains the number of ones in those four bits positions in the original n. Continuing this for five iterations, the 64 bits contain the number of ones among these sixty-four bit positions in the original n. That is what we wanted to compute.

=cut

sub TWO {    # (c)
    ( 0x1 << (shift) );
}

sub MASK {    #(c)
    (
        (     # (unsigned int)(-1)
            ~0
        ) / ( TWO( TWO(shift) ) + 1 )
    );
}

my @Mask;
INIT {
    $Mask[$_] = MASK($_) for 0 .. 4;
}

sub COUNT {    #(x,c)
    my ( $x, $c ) = @_;
    ( ($x) & $Mask[$c] ) + ( ( ($x) >> ( TWO($c) ) ) & $Mask[$c] );
}

printf "%d: '%032b' 0x'%X' \n", $_, $Mask[$_], $Mask[$_] for 0 .. 4;

sub par_mask {    #(unsigned int n)

    my $n = shift;
    printf "-: '%032b' \n", $n;

    # $n = COUNT($n, 0) ;
    $n = ( ($n) & $Mask[0] ) + ( ( ($x) >> ( 1 << (0) ) ) & $Mask[0] );
    printf "%d: '%032b' \n", 0, $n;

    #  $n = COUNT($n, 1) ;
    $n = ( ($n) & $Mask[1] ) + ( ( ($x) >> ( 1 << (1) ) ) & $Mask[1] );
    printf "%d: '%032b' \n", 1, $n;

    #   $n = COUNT($n, 2) ;
    $n = ( ($n) & $Mask[2] ) + ( ( ($x) >> ( 1 << (2) ) ) & $Mask[2] );
    printf "%d: '%032b' \n", 2, $n;

    #   $n = COUNT($n, 3) ;
    $n = ( ($n) & $Mask[3] ) + ( ( ($x) >> ( 1 << (3) ) ) & $Mask[3] );
    printf "%d: '%032b' \n", 3, $n;

    #   $n = COUNT($n, 4) ;
    $n = ( ($n) & $Mask[4] ) + ( ( ($x) >> ( 1 << (4) ) ) & $Mask[4] );
    printf "%d: '%032b' \n", 4, $n;

    # 	/* n = COUNT(n, 5) ;    for 64-bit integers */
    return n;
}

par_mask( 7 + ( 1 << 8 ) + ( 3 << 24 ) );
