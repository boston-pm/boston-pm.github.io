#!/usr/local/bin/perl
# initial perl from
# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/1062.html
# but many more from C fragments noted and other CLPM posts as noted
# see also http://en.wikipedia.org/wiki/Hamming_weight

use strict;
use warnings;
use Benchmark qw( :all);

# use Text::Table;

# goto bench;

#my $tb = Text::Table->new( qw( n bin), \' | ',
#    qw( direct decrement ilya table)
#);
#for ( 1 .. 3 ) {
#    my $x = int rand( 2**32);
#    $tb->add( $x, sprintf( "%32b", $x),
#    direct( $x), decrement( $x), ilya( $x), table( $x));
#}
#print $tb;
#exit;

# bench:

cmpthese(
    -5,
    {
        direct       => 'direct( int rand 2**32)',
        decrement    => 'decrement( int rand 2**32)',
        ilya         => 'ilya( int rand 2**32)',
        table        => 'table( int rand 2**32)',
        unrolled     => 'unrolled( int rand 2**32)',
        table_unroll => 'table_unroll( int rand 2**32)',
        katz         => 'katz( int rand 2**32)',
        builtin_bc   => 'builtin_bc( int rand 2**32)',
        ls1b         => 'ls1b( int rand 2**32)',
        nifty_par    => 'nifty_par( int rand 2**32)',
        rec_n        => 'rec_n( int rand 2**32)',
        sprintftr    => 'sprintftr( int rand 2**32)',
        hakmem_169   => 'hakmem_169( int rand 2**32)',

        #    via_bitvec => 'via_bitvec( int rand 2**32)',
    }
);

###################################################################

# bit counting
# see also
# http://infolab.stanford.edu/~manku/bitcount/bitcount.html
# moved to > http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/
# http://www.setbb.com/phpbb/viewtopic.php?mforum=sudoku&p=7629
# http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/

sub hakmem_169 {

# octal 11111111111 = decimal 1227133513 =  hex 0x49249249 = (as time_t) Wed Nov 19 22:25:13 UTC 2008
# This number is sacred to HAKMEM 169, bitcount.
# http://blogs.msdn.com/jeuge/archive/2005/06/08/HAKMEM-Bit-Count.aspx
# http://www.inwap.com/pdp10/hbaker/hakmem/hakmem.html
# http://www.inwap.com/pdp10/hbaker/hakmem/hacks.html#item169
# For 64-bit numbers, we would have to add triples of octal digits and use modulus 1023
## does that make it loglog N ?
    my $u = shift;
    my $uCount =
      $u - ( ( $u >> 1 ) & 033333333333 ) - ( ( $u >> 2 ) & 011111111111 );
    return ( ( $uCount + ( $uCount >> 3 ) ) & 030707070707 ) % 63;

}
### would & 63 or 0x3F be faster  and still correct ?

sub rec_n {

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0642.html
# Recursive approach, terse and elegant IMHO.
# An iterative one is OK as well.
    my $n = shift;
    return 0 unless $n;
    return ( $n & 1 ) + rec_n( $n >> 1 );
}

sub sprintftr {

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0785.html
    qq.@{[map sprintf('%b',$_),@_]}. =~ tr/1//;
}

sub direct {
    my $x     = shift;
    my $count = 0;
    while ($x) {
        $count += $x & 1;
        $x >>= 1;
    }
    $count;
}

sub decrement {
    my $x     = shift;
    my $count = 0;
    while ($x) {
        $count++;
        $x &= $x - 1;
    }
    $count;
}

sub ilya {

    # claims log N time
    my $x     = shift;
    my $shift = 1;
    for my $mask ( 0x55555555, 0x33333333, 0x0f0f0f0f, 0x00ff00ff, 0x0000ffff )
    {
        $x = ( $x & $mask ) + ( ( $x >> $shift ) & $mask );
        $shift *= 2;
    }
    $x;
}

sub unrolled    # ilya unrolled
{

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/1067.html
# aka #4 on http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/
    my $n = shift;

    # can use same mask twice if shift $n then mask
    # n = (n & MASK_01010101) + ((n >> 1) & MASK_01010101) ;
    $n = ( $n & 0x55555555 ) + ( ( $n & 0xaaaaaaaa ) >> 1 );
    $n = ( $n & 0x33333333 ) + ( ( $n & 0xcccccccc ) >> 2 );
    $n = ( $n & 0x0f0f0f0f ) + ( ( $n & 0xf0f0f0f0 ) >> 4 );
    $n = ( $n & 0x00ff00ff ) + ( ( $n & 0xff00ff00 ) >> 8 );
    $n = ( $n & 0x0000ffff ) + ( ( $n & 0xffff0000 ) >> 16 );

    $n;
}

sub nifty_par    # ilya unrolled plus modulus
{

# #5 on http://gurmeetsingh.wordpress.com/2008/08/05/fast-bit-counting-routines/
    my $n = shift;

    # can use same mask twice if shift $n then mask
    # n = (n & MASK_01010101) + ((n >> 1) & MASK_01010101) ;
    $n = ( $n & 0x55555555 ) + ( ( $n & 0xaaaaaaaa ) >> 1 );
    $n = ( $n & 0x33333333 ) + ( ( $n & 0xcccccccc ) >> 2 );
    $n = ( $n & 0x0f0f0f0f ) + ( ( $n & 0xf0f0f0f0 ) >> 4 );

    # $n = ($n & 0x00ff00ff) + (($n & 0xff00ff00) >> 8);
    # $n = ($n & 0x0000ffff) + (($n & 0xffff0000) >> 16);
    return $n % 255;
}

sub katz {

    # from ftp.port80.se/pub/CPAN/authors/id/Y/YA/YARBER/kat.pl-1.03
    my $list = unpack(
        'B*', shift    # $data
    );
    $list =~ tr/0//d;

    # my $len = length($data);
    my $total = length($list);

    #my $avg = $len * 4;
    #my $dif = $total - $avg;
    #print("$len bytes, $total 1-bits ($avg + $dif)\n\n");
    return $total;
}

sub builtin_bc {

# http://perldoc.perl.org/perlpacktut.html#Doing-Sums
# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0656.html
    my $bitcount = unpack( '%32b*', shift );

}

sub ls1b {

# size2 http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/0656.html
# Wegner-Kernighan
    my $n = shift;
    my $size = $n ? 1 : 0;
    $size++ while $n ^= ( ( $n - 1 ) ^ $n ) & $n;
    $size;
}

###############
# trade space for time ...
# and still is proprotional to wordsize N linear
#
my @table;

BEGIN {
    $table[$_] = direct($_)
      for 0 .. 255;    # not the most efficient pre-computation either ...
}

sub table {
    my $x     = shift;
    my $count = 0;
    while ($x) {
        $count += $table[ $x & 255 ];
        $x >>= 8;
    }
    $count;
}

sub table_unroll {

# http://coding.derkeiler.com/Archive/Perl/comp.lang.perl.misc/2003-11/1685.html
    my $x = shift;
    $table[ $x & 0xff ] +
      $table[ ( $x >> 8 ) & 0xff ] +
      $table[ ( $x >> 16 ) & 0xff ] +
      $table[ ( $x >> 24 ) & 0xff ];
}

################################
## module bitvec
__END__
  use Bit::Vector;

  my $vec = Bit::Vector->new(Bit::Vector->Word_Bits());



  sub via_bitvec {
      $vec->Word_Store(0,$_[0]);
      $vec->Norm();
  }



