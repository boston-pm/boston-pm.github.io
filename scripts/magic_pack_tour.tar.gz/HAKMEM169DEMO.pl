#! perl -lw
use strict;
my $uCount;
my $n =    # 1024+7;
           #  01001234567;
  0xFFFFFFFF;

sub p { printf "%s\n", shift }

sub c {
    my ( $a, $x ) = @_;
    return $x unless $a;
    printf "(%s) %08x = %012o = %10u = %32b\n", $a, $x, $x, $x, $x;
    return $x;
}

c( n => $uCount = $n );
c( c => $uCount -= c( b => ( c( h => $n >> 1 ) & c( x => 033333333333 ) ) ) );
c( e => $uCount -= c( d => ( c( q => $n >> 2 ) & c( x => 011111111111 ) ) ) );
p( q/-/ x 80 );    #---------------------------------------
c( g => $uCount += c( f => ( $uCount >> 3 ) ) );
c( i => $uCount &= c( h => 030707070707 ) );
p( q/-/ x 80 );    #---------------------------------------
c( l => $uCount % c( k => 63 ) );

