#!/usr/bin/env perl 
use strict;
$|++;

use Image::ExifTool qw(ImageInfo);

use Time::Local;

for my $file (@ARGV) {
    my $ii = ImageInfo( $file, qw(DateTimeOriginal DateTime) )
      or warn("Skipping $file\n"), next;
    my ($created) =
      grep /\S/, @$ii{qw(DateTimeOriginal DateTime)};
    next unless $created;
    warn "using $created for $file\n";
    if ( $created =~ s/([-+ ])(\d\d):(\d\d)$// ) {
        my ( $sign, $hour, $minute ) = ( $1, $2, $3 );

        # warn "ignoring offset of $sign $hour:$minute\n";
    }
    my @digits = $created =~ /(\d+)/g or next;
    if ( $digits[0] < 1900 ) {
        warn "bad year $digits[0] for $file";
        next;
    }
    $digits[0] -= 1900;
    $digits[1] -= 1;
    my $gmtime = timegm( reverse @digits );
    if ( $gmtime > time or $gmtime < time - 86400 * 90 ) {
        warn "preposterous gmtime for $file: ", scalar gmtime $gmtime;

        # next;
    }
    utime( $gmtime, $gmtime, $file ) or warn "Cannot utime on $file: $!";
}
